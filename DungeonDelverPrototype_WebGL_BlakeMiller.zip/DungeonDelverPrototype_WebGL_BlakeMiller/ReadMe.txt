################################################
#   Dungeon Delver Prototype
#   Blake Miller
#   04/7/2021
################################################

___What are the controls to your game? How do we play?___
The controls to the game are either the W,A,S,D or the arrow keys. You can attack
by pressing the Z key. It plays as a 2D game where everything is on one axis of 
movement. So far there is only one room where you cannot leave from. You can move around
the level and open doors as well as take damage from the skeletos as well.

___What creative additions did you make? How can we find them?___
None

___Any assets used that you didn't create yourself? (art, music, etc. Just tell us where you got it, link it here)___
None

___Did you receive help from anyone outside this class? (list their names and what they helped with)___
No

___Did you get help from any online websites, videos, or tutorials? (link them here)___
No

___What trouble did you have with this project?___
None

___Is there anything else we should know?___
Nope