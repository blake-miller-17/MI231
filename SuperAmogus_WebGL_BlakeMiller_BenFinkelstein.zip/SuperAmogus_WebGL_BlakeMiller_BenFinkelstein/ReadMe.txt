################################################
#   Final Game
#   Blake Miller, Ben Finkelstein
#   4/28/2021
################################################

___What are the controls to your game? How do we play?___
Our game can be played by controlling the player either with the left or right arrow keys or
the A and D keys to move left or right, respectively. You can also 'fly' with the jetpack by 
using the space bar. Be careful though because you can run out of fuel causing you to fall to the ground.
There are weapons that you can obtain from the question mark blocks, and to fire you press z. To beat the
level, and game, you fight and destroy the boss at the rightmost portion of the level. 

___What creative additions did you make? How can we find them?___
We added powerups, enemies, custom level design, and models for a lot of the components used

___Any assets used that you didn't create yourself? (art, music, etc. Just tell us where you got it, link it here)___
We got a lot of assets from https://www.spriters-resource.com.

___Did you receive help from anyone outside this class? (list their names and what they helped with)___
No

___Did you get help from any online websites, videos, or tutorials? (link them here)___
Blackthornprod

___What trouble did you have with this project?___
There was some trouble trying to get the powerups to spawn properly out of the blocks

___Is there anything else we should know?___
There are four powerups: Missle(is a missle), Automatic(is a bullet), Spread(is a shotgun shell),
and Jetpack Refuel(is a jerry can). Be careful when getting a Jerry can though, it will make your
player lose its current weapon, so pick your trade off wisely.