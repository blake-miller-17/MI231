################################################
#   Space SHMUP
#   Blake Miller
#   3/14/2021
################################################

___What are the controls to your game? How do we play?___
You move the ship with the W,A,S,D keys and when you want to shoot a bullet you can
press space bar to shoot and destroy the enemy ships

___What creative additions did you make? How can we find them?___
None, no time :(
___Any assets used that you didn't create yourself? (art, music, etc. Just tell us where you got it, link it here)___
The assets we downloaded

___Did you receive help from anyone outside this class? (list their names and what they helped with)___
No

___Did you get help from any online websites, videos, or tutorials? (link them here)___
No

___What trouble did you have with this project?___
I had some trouble with the enemies but realized this was because I set them up wrong.

___Is there anything else we should know?___
Some of the headers of the scripts in the book are named wrong or maybe I just don't understand why they are named as they are. 
For example when we were editing the Enemy_0 script the header says "Code Listing 31.ac - Shield " but it should be EnemyShield.cs.
Because of this my projectileHero script is named projectile but the code all works as it should