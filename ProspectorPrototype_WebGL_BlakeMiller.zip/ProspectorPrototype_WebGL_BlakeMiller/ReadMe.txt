################################################
#   Prospector Prototype
#   Blake Miller
#   2/21/2021
################################################

___What are the controls to your game? How do we play?___
It is like a game of solitaire. When you click on a card that is one above or below the card
the card will increment the score and show that card as the target card. The game can be won or lost
and if the game is won then the score remains and the player is moved onto the next round. If 
the player loses then the game will restart and the score set back to 0.

___What creative additions did you make? How can we find them?___
I added the gold cards as my creative addition. This inlcudes assigning random 
cards (from 2 - 5 of them) with the gold sprite and then using those to increment the 
multiplier for the score.

___Any assets used that you didn't create yourself? (art, music, etc. Just tell us where you got it, link it here)___
None

___Did you receive help from anyone outside this class? (list their names and what they helped with)___
No

___Did you get help from any online websites, videos, or tutorials? (link them here)___
No

___What trouble did you have with this project?___
I wasn't able to get the multiplier to show up on screen or effect the score to my knowledge.
I found that this code was more challenging to understand but I also believe that the time I had
available to implement this was more of the issue than complete understanding of this code. 

___Is there anything else we should know?___
Not that I know of