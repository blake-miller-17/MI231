################################################
#   Apple Picker Prototype
#   Blake Miller
#   1/31/2021
################################################

___What are the controls to your game? How do we play?___
-The basket is controlled by the mouse and you control the mouse to collect the correct falling apples. 
-Details on the specific colors of the apple can be found in the instructions page.

___What creative additions did you make? How can we find them?___
-For my creative additions I added a main menu that has links to start the game, look at instructions, or quit.
-From the instructions page you can return to the main menu or start a game. I also added a cube that rotates
to show what colors represent certain apples.
I also added a Game over scene that will show when the player runs out of baskets. From there they can go back to the main
menu or start a new game.
I also created the main menu and game over art as well as the button art in photopea.

___Any assets used that you didn't create yourself? (art, music, etc. Just tell us where you got it, link it here)___
None

___Did you receive help from anyone outside this class? (list their names and what they helped with)___
No

___Did you get help from any online websites, videos, or tutorials? (link them here)___
https://www.youtube.com/watch?v=BjEqZfK15Ws%2CThere - Creating a Title Screen

https://docs.unity3d.com/ScriptReference/Transform.Rotate.html - Rotate

___What trouble did you have with this project?___
I had some trouble trying to add an enhancment to my project. I really wanted to have the screen be warped or
have an effect after the player collected a poison apple. I couldn't get any effects that made me happy so I 
didn't include any. 

___Is there anything else we should know?___
The shapes in the instructions screen are cubes because you can see them rotate unlike spheres.
The Main menu is a little blurry but the other font seems to be alright. Im not sure why its only that
canvas.