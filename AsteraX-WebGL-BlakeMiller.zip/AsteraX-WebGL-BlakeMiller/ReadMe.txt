################################################
#   AsteraX
#   Blake Miller
#   1/31/2021
################################################

___What are the controls to your game? How do we play?___
Use the WASD keys to move around. Use the mouse to aim and shoot at the asteroids. Shoot all the asteroids to win.

___What creative additions did you make? How can we find them?___
Messed with particles but essentially none.

___Any assets used that you didn't create yourself? (art, music, etc. Just tell us where you got it, link it here)___
None.

___Did you receive help from anyone outside this class? (list their names and what they helped with)___
No.

___Did you get help from any online websites, videos, or tutorials? (link them here)___
No.

___What trouble did you have with this project?___
N/A.

___Is there anything else we should know?___
Nope.